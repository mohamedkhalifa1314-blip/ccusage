const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('api', {
  getSettings: () => ipcRenderer.invoke('settings:get'),
  setSettings: (s) => ipcRenderer.invoke('settings:set', s),
  chooseDir: () => ipcRenderer.invoke('dialog:chooseDir'),
  runReport: (opts) => ipcRenderer.invoke('report:run', opts),
  saveFile: (opts) => ipcRenderer.invoke('export:save', opts),
  getPricing: () => ipcRenderer.invoke('meta:pricing'),
  getPlaybook: () => ipcRenderer.invoke('meta:playbook'),
  toCsv: (report) => ipcRenderer.invoke('meta:csv', report),
});