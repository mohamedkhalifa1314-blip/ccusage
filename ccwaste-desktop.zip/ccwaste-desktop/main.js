// main.js — Electron main process (ESM).
import { app, BrowserWindow, ipcMain, dialog } from 'electron';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import { buildDemo } from './demo.js';
import {
  runReport, toCsv, PLAYBOOK,
  MODELS, TIER_ORDER, TIER_LABEL, TIER_KEY,
} from './core.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const settingsFile = () => path.join(app.getPath('userData'), 'settings.json');

function readSettings() {
  try { return JSON.parse(fs.readFileSync(settingsFile(), 'utf8')); }
  catch { return { dir: '' }; }
}
function writeSettings(s) {
  const clean = { dir: typeof s?.dir === 'string' ? s.dir.trim() : '' };
  fs.mkdirSync(path.dirname(settingsFile()), { recursive: true });
  fs.writeFileSync(settingsFile(), JSON.stringify(clean, null, 2));
  return clean;
}

let win;
function createWindow() {
  win = new BrowserWindow({
    width: 1200,
    height: 800,
    backgroundColor: '#0d1117',
    title: 'ccwaste',
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
    },
  });
  win.loadFile(path.join(__dirname, 'renderer', 'index.html'));
}

ipcMain.handle('settings:get', () => readSettings());
ipcMain.handle('settings:set', (_e, s) => writeSettings(s));

ipcMain.handle('dialog:chooseDir', async () => {
  const r = await dialog.showOpenDialog(win, { properties: ['openDirectory'] });
  return r.canceled ? null : r.filePaths[0];
});

ipcMain.handle('report:run', (_e, opts = {}) => {
  try {
    const { dir } = readSettings();
    let root = dir ? dir.replace(/^~(?=$|[\\/])/, app.getPath('home')) : undefined;
    if (opts.demo) root = buildDemo(path.join(app.getPath('temp'), 'ccwaste-demo'));
    return runReport({
      root,
      days: Number(opts.days ?? 7),
      projectFilter: opts.projectFilter || null,
      minUsd: Number(opts.minUsd ?? 0.03),
      top: Number(opts.top ?? 5),
    });
  } catch (err) {
    return { error: String(err?.message || err) };
  }
});

ipcMain.handle('export:save', async (_e, { defaultName, content, filters } = {}) => {
  const r = await dialog.showSaveDialog(win, {
    defaultPath: defaultName || 'ccwaste-report.txt',
    filters: filters || [],
  });
  if (r.canceled || !r.filePath) return { canceled: true };
  fs.writeFileSync(r.filePath, content ?? '', 'utf8');
  return { canceled: false, path: r.filePath };
});

ipcMain.handle('meta:pricing', () => ({ models: MODELS, tierOrder: TIER_ORDER, tierLabel: TIER_LABEL, tierKey: TIER_KEY }));
ipcMain.handle('meta:playbook', () => PLAYBOOK);
ipcMain.handle('meta:csv', (_e, report) => toCsv(report));

app.whenReady().then(() => {
  createWindow();
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
});
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
