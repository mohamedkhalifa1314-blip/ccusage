// demo.js — writes fake Claude Code session logs so every tab has data.
// Numbers are synthetic. Nothing here reads or touches real logs.
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';

function rng(seed) {
  return () => {
    seed |= 0; seed = (seed + 0x6D2B79F5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function buildDemo(root) {
  fs.rmSync(root, { recursive: true, force: true });
  const rand = rng(42);
  const home = os.homedir();
  const now = Date.now();
  let uid = 0;

  const projects = {
    'web-store': path.join(home, 'projects', 'web-store'),
    'api-server': path.join(home, 'projects', 'api-server'),
    'mobile-app': path.join(home, 'projects', 'mobile-app'),
  };

  // spec: { project, model, daysAgo, turns, startCtx, growth, steps[] }
  // step: { prompt?, tool?, input?, result? }
  function writeSession(name, spec) {
    const dir = path.join(root, '-' + spec.project);
    fs.mkdirSync(dir, { recursive: true });
    const cwd = projects[spec.project];
    const lines = [];
    let t = now - spec.daysAgo * 864e5;
    const stamp = () => new Date((t += 20000 + rand() * 40000)).toISOString();
    for (let i = 0; i < spec.turns; i++) {
      const step = spec.steps[i % spec.steps.length];
      if (step.prompt && (i < spec.steps.length || spec.repeatPrompts)) {
        lines.push({ type: 'user', timestamp: stamp(), cwd, message: { role: 'user', content: step.prompt } });
      }
      const ctx = Math.round(spec.startCtx + i * spec.growth);
      const cw = Math.round(1200 + rand() * 2500);
      const cr = Math.max(0, ctx - cw);
      const toolId = 'toolu_' + (++uid);
      const content = [{ type: 'text', text: 'Working on it.' }];
      if (step.tool) content.push({ type: 'tool_use', id: toolId, name: step.tool, input: step.input || {} });
      lines.push({
        type: 'assistant', timestamp: stamp(), cwd,
        message: {
          id: 'msg_' + (++uid), model: spec.model, role: 'assistant', content,
          usage: {
            input_tokens: Math.round(30 + rand() * 200),
            output_tokens: Math.round(spec.out ?? 300 + rand() * 900),
            cache_creation_input_tokens: cw,
            cache_read_input_tokens: cr,
          },
        },
      });
      if (step.tool) {
        lines.push({
          type: 'user', timestamp: stamp(), cwd,
          message: { role: 'user', content: [{ type: 'tool_result', tool_use_id: toolId, content: step.result || 'ok' }] },
        });
      }
    }
    fs.writeFileSync(path.join(dir, name + '.jsonl'), lines.map((l) => JSON.stringify(l)).join('\n') + '\n');
  }

  const bigFile = 'export function render() {\n' + '  const x = compute(items);\n'.repeat(12000);
  const readRender = { tool: 'Read', input: { file_path: path.join(projects['web-store'], 'src/render.js') }, result: bigFile };
  const failTest = { tool: 'Bash', input: { command: 'npm test' }, result: 'FAIL src/cart.test.js\n  2 failures\nTypeError: cannot read properties of undefined\n' + '    at stack frame\n'.repeat(9000) };

  // 1. Opus on a tiny edit task: model-switch finding.
  writeSession('demo-rename', {
    project: 'web-store', model: 'claude-opus-5-5', daysAgo: 1, turns: 14, startCtx: 18000, growth: 1500,
    steps: [
      { prompt: 'rename the variable cartTotal to totalPrice in src/cart.js' },
      { tool: 'Grep', input: { pattern: 'cartTotal' }, result: 'src/cart.js:12: cartTotal\nsrc/cart.js:40: cartTotal' },
      { tool: 'Edit', input: { file_path: path.join(projects['web-store'], 'src/cart.js'), old_string: 'cartTotal', new_string: 'totalPrice' } },
    ],
  });
  // 2. Repeated reads of one file with no edits.
  writeSession('demo-rereads', {
    project: 'web-store', model: 'claude-sonnet-5-5', daysAgo: 2, turns: 24, startCtx: 30000, growth: 2500,
    steps: [{ prompt: 'improve the rendering' }, readRender, { tool: 'Grep', input: { pattern: 'render' }, result: 'src/render.js: 3 matches' }],
  });
  // 3. Tool loop: same failing command, same result.
  writeSession('demo-loop', {
    project: 'api-server', model: 'claude-opus-5-5', daysAgo: 2, turns: 18, startCtx: 40000, growth: 2000,
    steps: [{ prompt: 'fix the failing tests' }, failTest],
  });
  // 4. Very long session, context balloons.
  writeSession('demo-long', {
    project: 'api-server', model: 'claude-opus-5-5', daysAgo: 3, turns: 110, startCtx: 20000, growth: 2100,
    steps: [
      { prompt: 'build the orders endpoint, then the invoices endpoint, then add pagination everywhere' },
      { tool: 'Read', input: { file_path: path.join(projects['api-server'], 'src/orders.js') }, result: 'orders code '.repeat(400) },
      { tool: 'Edit', input: { file_path: path.join(projects['api-server'], 'src/orders.js') } },
      { tool: 'Bash', input: { command: 'npm run build' }, result: 'build ok' },
    ],
  });
  // 5. Big paste + multi-task prompt.
  writeSession('demo-paste', {
    project: 'mobile-app', model: 'claude-sonnet-5-5', daysAgo: 4, turns: 16, startCtx: 25000, growth: 3000,
    steps: [
      { prompt: 'here is the log:\n' + 'ERROR network timeout at line\n'.repeat(1200) + '\nplease fix' },
      { prompt: '1. fix login\n2. fix signup\n3. add dark mode\n4. update icons\n5. bump version' },
      { tool: 'Edit', input: { file_path: path.join(projects['mobile-app'], 'App.js') } },
      { tool: 'Bash', input: { command: 'npm run lint' }, result: 'lint ok' },
    ],
  });
  // 6-9. Assorted normal sessions on different models/days.
  const mixes = [
    ['demo-a', 'web-store', 'claude-sonnet-5-5', 5, 30, 15000, 1800, 'write a unit test for the cart module'],
    ['demo-b', 'mobile-app', 'claude-opus-5-5', 5, 22, 22000, 2200, 'update the readme with install steps'],
    ['demo-c', 'api-server', 'claude-haiku-5-5', 6, 12, 8000, 900, 'add a health check route'],
    ['demo-d', 'mobile-app', 'claude-sonnet-5-5', 6, 40, 20000, 2600, 'implement the settings screen'],
    ['demo-e', 'web-store', 'claude-fable-5-2', 1, 20, 35000, 2800, 'design the checkout architecture and review tradeoffs'],
  ];
  for (const [name, project, model, daysAgo, turns, startCtx, growth, prompt] of mixes) {
    const file = path.join(projects[project], 'src/main.js');
    writeSession(name, {
      project, model, daysAgo, turns, startCtx, growth,
      steps: [
        { prompt },
        { tool: 'Read', input: { file_path: file }, result: 'source '.repeat(200 + Math.round(rand() * 200)) },
        { tool: 'Edit', input: { file_path: file } },
        { tool: 'Bash', input: { command: 'npm test' }, result: 'all tests passed' },
      ],
    });
  }
  return root;
}
