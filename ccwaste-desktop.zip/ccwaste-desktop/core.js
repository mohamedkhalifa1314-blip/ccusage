// core.js — ccwaste analysis library. Pure functions, returns plain JSON.
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import crypto from 'node:crypto';

// ---------------------------------------------------------------------------
// 1. Pricing
// ---------------------------------------------------------------------------
export const MODELS = {
  'fable-5-2':  { tier: 'fable',  label: 'Fable 5.2',  in: 8,    out: 40,  cw: 10,    cr: 0.20 },
  'opus-5-5':   { tier: 'opus',   label: 'Opus 5.5',   in: 4,    out: 20,  cw: 5,     cr: 0.20 },
  'opus-5':     { tier: 'opus',   label: 'Opus 5',     in: 5,    out: 25,  cw: 6.25,  cr: 0.50 },
  'sonnet-5-5': { tier: 'sonnet', label: 'Sonnet 5.5', in: 2,    out: 10,  cw: 2.5,   cr: 0.10 },
  'sonnet-5':   { tier: 'sonnet', label: 'Sonnet 5',   in: 2,    out: 10,  cw: 2.5,   cr: 0.20 },
  'haiku-5-5':  { tier: 'haiku',  label: 'Haiku 5.5',  in: 0.10, out: 0.50, cw: 0.125, cr: 0.01,
                  hi: { in: 0.50, out: 2.50, cw: 0.625, cr: 0.05 } },
};
export const UNPRICED_FALLBACK = { tier: 'unknown', label: null, in: 2, out: 10, cw: 2.5, cr: 0.10 };
export const TIER_RANK = { haiku: 0, sonnet: 1, opus: 2, fable: 3 };
export const TIER_ORDER = ['haiku', 'sonnet', 'opus', 'fable'];
export const TIER_LABEL = { haiku: 'Haiku 5.5', sonnet: 'Sonnet 5.5', opus: 'Opus 5.5', fable: 'Fable 5.2' };
export const TIER_KEY   = { haiku: 'haiku-5-5', sonnet: 'sonnet-5-5', opus: 'opus-5-5', fable: 'fable-5-2' };

export function normModel(m) {
  if (!m) return '';
  return String(m).toLowerCase().replace(/^claude-/, '').replace(/-\d{8}$/, '');
}
export function modelOf(key) { return MODELS[key] || null; }
export function priceForTier(tier, ctxTokens = 0) {
  const key = TIER_KEY[tier];
  if (!key) return null;
  const m = MODELS[key];
  return m.hi && ctxTokens > 100_000 ? m.hi : m;
}
export function priceForModel(m, ctxTokens) {
  return m.hi && ctxTokens > 100_000 ? m.hi : m;
}
export function costOf(i, o, cw, cr, p) {
  return (i * p.in + o * p.out + cw * p.cw + cr * p.cr) / 1e6;
}

// ---------------------------------------------------------------------------
// 2. Capability matrix
// ---------------------------------------------------------------------------
const TASKS = {
  lookup:           { label: 'Quick lookup / Q&A',        min: 'haiku',  why: 'read-only, short, no edits' },
  'simple-edit':    { label: 'Simple edit / formatting',  min: 'haiku',  why: '1–2 edits, one file, short' },
  boilerplate:      { label: 'Boilerplate / scaffolding', min: 'haiku',  why: 'many new files, little judgment' },
  'routine-coding': { label: 'Routine coding',            min: 'sonnet', why: 'edits + tests, bounded scope' },
  'test-writing':   { label: 'Test writing',              min: 'sonnet', why: 'pattern-following, verification' },
  review:           { label: 'Code review',               min: 'sonnet', why: 'read-heavy, diff-sized output' },
  investigation:    { label: 'Investigation / tracing',   min: 'sonnet', why: 'many reads, one explanation' },
  writing:          { label: 'Writing / analysis',        min: 'sonnet', why: 'long prose output, no edits' },
  debug:            { label: 'Debugging',                 min: 'sonnet', why: 'fail → edit → re-run loops' },
  refactor:         { label: 'Cross-cutting refactor',    min: 'opus',   why: 'many files, churn, judgment' },
  architecture:     { label: 'Architecture / design',     min: 'opus',   why: 'few tools, long reasoning' },
  'open-ended':     { label: 'Open-ended / ambiguous',    min: 'opus',   why: 'long context, many turns' },
};

const HELP_WHY = {
  lookup: 'Reads and greps with no edits. Haiku answers these at ~1/20th the price.',
  'simple-edit': 'One or two small edits. Haiku handles formatting and renames reliably.',
  boilerplate: 'New files that follow a template. Haiku is fast and cheap here.',
  'routine-coding': 'Bounded coding with tests. Sonnet is the default for a reason.',
  'test-writing': 'Writing tests against an existing pattern. Sonnet is sufficient.',
  review: 'Reading diffs and commenting. Sonnet reads just as well for 1/2 the price.',
  investigation: 'Tracing code paths to answer one question. Sonnet is enough.',
  writing: 'Long prose or analysis with no code changes. Sonnet writes well.',
  debug: 'Finding a bug is judgment-heavy; small debug stays on Sonnet, hard debug goes to Opus.',
  refactor: 'Cross-cutting changes need sustained judgment. Opus earns its price here.',
  architecture: 'Design decisions and trade-offs. Opus is the daily driver for this.',
  'open-ended': 'Ambiguous, long-horizon work. Opus holds the thread better than Sonnet.',
};

export const PLAYBOOK = `
ccwaste playbook — how to say things so Claude spends less

1. Name the file and the done state.
   Bad:  "fix the bug"
   Good: "In src/auth.ts, login() throws on null email. Return 401 instead. Run npm test auth to confirm."
   Why:  A target + a test stops exploration. Exploration is the most expensive part of a session.

2. Quote the failing line, not the whole log.
   Bad:  paste 400 lines of output
   Good: "The failure is 'ECONNREFUSED 5432' in the last run. Check if Postgres is up; if not, start it."
   Why:  Tool output is re-sent on every turn. Small outputs, large savings.

3. One task per chat; /clear between unrelated tasks.
   Bad:  "rename X, then also fix Y, and update the docs"
   Good: "Rename X."  → /clear → "Fix Y."  → /clear → "Update the docs."
   Why:  /clear is the single biggest lever for both cost and quality.

4. Put facts in CLAUDE.md, not in the prompt.
   Bad:  re-paste the same API shape every session
   Good: "The API shape and error codes are in CLAUDE.md. Use them; don't re-read the client."
   Why:  A cached CLAUDE.md is cheap; repeated reads are not.

5. Interrupt loops with a constraint, not "try again".
   Bad:  "try again"
   Good: "Stop. The issue is the retry wraps the whole function. Only wrap the network call."
   Why:  Identical calls with identical output mean the model is missing information, not effort.

6. Right-size the model to the task, not the mood.
   Bad:  Fable for a rename.
   Good: "Use Sonnet for this — it is a bounded edit."
   Why:  Fable is for work Opus cannot crack; Sonnet handles most coding at half Opus's price.

7. Ask for the plan before the edits.
   Bad:  "build the feature"
   Good: "Propose a 5-step plan first. Do not edit until I approve."
   Why:  A cheap plan turn prevents an expensive wrong-direction session.

8. Constrain output when you only need the answer.
   Bad:  "explain everything"
   Good: "Answer in 5 lines. No preamble. Show the diff only."
   Why:  Output tokens cost 5× input on every current model. Brevity is the cheapest optimization.

9. Use medium effort for routine work.
   Bad:  xhigh effort on a rename
   Good: "Medium effort. This is a mechanical change."
   Why:  Effort controls total token spend, not just thinking tokens.

10. When a session reaches ~150k context, /compact or /clear.
    Bad:  keep going in a 200k-token chat
    Good: "/compact, then continue." Or /clear and restate the task in one line.
    Why:  Every turn re-sends the whole context. The older the chat, the more you pay per message.
`;

// ---------------------------------------------------------------------------
// 3. Utility
// ---------------------------------------------------------------------------
export const tok = (chars) => Math.ceil(chars / 4);
export const fmt = (n) =>
  n >= 1e9 ? (n / 1e9).toFixed(1) + 'B' :
  n >= 1e6 ? (n / 1e6).toFixed(1) + 'M' :
  n >= 1e3 ? (n / 1e3).toFixed(1) + 'k' : String(Math.round(n));
export const usd = (n) => {
  if (!Number.isFinite(n)) return '$?';
  if (n === 0) return '$0';
  const sign = n < 0 ? '-' : '';
  const a = Math.abs(n);
  if (a >= 100) return sign + '$' + Math.round(a);
  if (a >= 0.01) return sign + '$' + a.toFixed(2);
  return sign + '<$0.01';
};
export const pct = (a, b) => (b > 0 ? Math.round((a / b) * 1000) / 10 : 0);

const HOME = os.homedir();
function pretty(p) {
  if (!p) return p;
  const rel = path.relative(HOME, p);
  if (rel === '') return '~';
  if (rel === '..' || rel.startsWith('..' + path.sep) || path.isAbsolute(rel)) return p;
  return '~' + path.sep + rel;
}

function textLen(c) {
  if (typeof c === 'string') return c.length;
  if (Array.isArray(c)) return c.reduce((n, b) => n + (b && b.text ? b.text.length : b && b.type === 'image' ? 1000 : 0), 0);
  return c ? JSON.stringify(c).length : 0;
}
function textOf(c) {
  if (typeof c === 'string') return c;
  if (Array.isArray(c)) return c.map((b) => (b && b.text) || (b && b.type === 'image' ? '[image]' : '')).join('\n');
  return c ? JSON.stringify(c) : '';
}
const sig = (c) => crypto.createHash('sha1').update(textOf(c)).digest('hex');
const claim = (owners, id, file) => {
  if (!id) return true;
  const o = owners.get(id);
  if (o === undefined) { owners.set(id, file); return true; }
  return o === file;
};
function bashFailed(text) {
  if (!text) return false;
  const cleaned = text
    .replace(/\b0\s+(?:failures?|errors?|failed)\b/gi, '')
    .replace(/\b(?:all|tests?|checks?)\s+(?:passed|ok|successful|green)\b/gi, '')
    .replace(/\b0\s+problems?\b/gi, '')
    .replace(/\bnot found;?\s*(?:skipping|ignoring|continuing)\b/gi, '');
  return /\b(?:[1-9]\d*\s+(?:failures?|errors?)|failure[: ]|exception|traceback|(?:file|command|module|symbol|path|script|binary|executable)\s+not found|cannot find|connection refused|permission denied)\b/i.test(cleaned);
}

// ---------------------------------------------------------------------------
// 4. Transcript analysis
// ---------------------------------------------------------------------------
export function analyzeSession(file, owners, cutoff, unpriced) {
  let raw;
  try { raw = fs.readFileSync(file, 'utf8'); } catch { return null; }
  const s = {
    cwd: null, file,
    usage: new Map(),
    mainUsage: new Map(),
    byModel: new Map(),
    tools: new Map(),
    reads: new Map(),
    repeats: new Map(),
    toolTokens: new Map(),
    gen: new Map(),
    readFiles: new Set(),
    wasCreated: new Set(),
    writesByFile: new Map(),
    userPrompts: [],
    bashCmds: [], bashFails: [],
    assistantText: 0,
    mainAssistantText: 0,
  };
  let anon = 0, mainTurns = 0, totalTurns = 0;

  for (const line of raw.split('\n')) {
    if (!line) continue;
    let rec;
    try { rec = JSON.parse(line); } catch { continue; }

    if (cutoff > 0 && rec.timestamp) {
      const ts = Date.parse(rec.timestamp);
      if (Number.isFinite(ts) && ts < cutoff) continue;
    }
    if (rec.cwd && !s.cwd) s.cwd = rec.cwd;
    const m = rec.message;
    if (!m) continue;

    if (rec.type === 'assistant') {
      const mid = m.id || rec.uuid;
      const mk = normModel(m.model || rec.model);

      if (m.usage && (!mid || claim(owners, 'm:' + mid, file))) {
        const u = m.usage;
        const ti = u.input_tokens || 0, to = u.output_tokens || 0;
        const tcw = u.cache_creation_input_tokens || 0, tcr = u.cache_read_input_tokens || 0;
        if (ti + to + tcw + tcr > 0) {
          const key = mid || ('anon:' + (anon++));
          const isSide = !!rec.isSidechain;
          s.usage.set(key, { u, isSidechain: isSide, mk });
          if (!isSide) s.mainUsage.set(key, { u, mk });
          totalTurns++; if (!isSide) mainTurns++;

          const model = modelOf(mk);
          const e = s.byModel.get(mk) || { i: 0, o: 0, cw: 0, cr: 0, cost: 0, unpriced: false };
          e.i += ti; e.o += to; e.cw += tcw; e.cr += tcr;
          if (model) {
            e.cost += costOf(ti, to, tcw, tcr, priceForModel(model, ti + tcw + tcr));
          } else {
            e.unpriced = true; unpriced.add(mk);
            e.cost += costOf(ti, to, tcw, tcr, UNPRICED_FALLBACK);
          }
          s.byModel.set(mk, e);
        }
      }

      if (typeof m.content === 'string') {
        s.assistantText += m.content.length;
        if (!rec.isSidechain) s.mainAssistantText += m.content.length;
      }
      if (!Array.isArray(m.content)) continue;

      if (rec.isSidechain) {
        for (const b of m.content) if (b && b.type === 'text' && b.text) s.assistantText += b.text.length;
        continue;
      }
      for (const b of m.content) {
        if (b && b.type === 'text' && b.text) {
          s.assistantText += b.text.length;
          s.mainAssistantText += b.text.length;
        }
        if (!b || b.type !== 'tool_use' || !b.id || s.tools.has(b.id) || !claim(owners, 't:' + b.id, file)) continue;
        const inp = b.input || {};
        const f = inp.file_path || inp.path || null;

        if (b.name === 'Write' && f) {
          if (!s.gen.has(f) && !s.readFiles.has(f)) s.wasCreated.add(f);
          s.writesByFile.set(f, (s.writesByFile.get(f) || 0) + 1);
          s.gen.set(f, (s.gen.get(f) || 0) + 1);
        } else if (b.name === 'Edit' && f) {
          s.gen.set(f, (s.gen.get(f) || 0) + 1);
        } else if (b.name === 'MultiEdit' && f) {
          const n = Array.isArray(inp.edits) ? Math.max(1, inp.edits.length) : 1;
          s.gen.set(f, (s.gen.get(f) || 0) + n);
        } else if (b.name === 'NotebookEdit' && f) {
          s.gen.set(f, (s.gen.get(f) || 0) + 1);
        }

        if (b.name === 'Bash' && inp.command) s.bashCmds.push(String(inp.command).slice(0, 200));
        const isRead = b.name === 'Read' && f;
        if (isRead) s.readFiles.add(f);
        const label = b.name + ' ' + String(inp.command || inp.pattern || f || '').replace(/\s+/g, ' ').slice(0, 70);
        let readKey = null, key = null;
        if (isRead) {
          readKey = f + '#' + (inp.offset || 0) + ':' + (inp.limit || '') + '@' + (s.gen.get(f) || 0);
          const r = s.reads.get(readKey) || { file: f, count: 0, tokens: 0 };
          r.count++;
          s.reads.set(readKey, r);
        } else if (!['TodoWrite','BashOutput','TaskOutput','TaskList','TaskUpdate','KillShell','ExitPlanMode'].includes(b.name) &&
                   !['Edit','MultiEdit','Write','NotebookEdit'].includes(b.name)) {
          key = b.name + ':' + JSON.stringify(inp).slice(0, 300);
          if (!s.repeats.has(key)) s.repeats.set(key, { label, results: new Map() });
        }
        s.tools.set(b.id, { name: b.name, readKey, key });
      }
    } else if (rec.type === 'user') {
      if (rec.isSidechain) continue;

      let hasToolResult = false;
      if (Array.isArray(m.content)) {
        for (const b of m.content) if (b && b.type === 'tool_result') { hasToolResult = true; break; }
      }
      if (!hasToolResult) {
        if (typeof m.content === 'string') s.userPrompts.push(m.content);
        else if (Array.isArray(m.content)) {
          for (const b of m.content) if (b && b.type === 'text' && b.text) s.userPrompts.push(b.text);
        }
      }
      if (!Array.isArray(m.content)) continue;
      for (const b of m.content) {
        if (!b || b.type !== 'tool_result') continue;
        const t = s.tools.get(b.tool_use_id);
        if (!t) continue;
        const text = textOf(b.content);
        const n = tok(textLen(b.content));
        s.toolTokens.set(t.name, (s.toolTokens.get(t.name) || 0) + n);
        if (t.name === 'Bash' && bashFailed(text)) {
          s.bashFails.push(text.replace(/\s+/g, ' ').slice(0, 160));
        }
        if (t.readKey && s.reads.has(t.readKey)) s.reads.get(t.readKey).tokens += n;
        else if (t.key && s.repeats.has(t.key)) {
          const res = s.repeats.get(t.key).results;
          const h = sig(b.content);
          const g = res.get(h) || { n: 0, tokens: 0 };
          g.n++; g.tokens += n;
          res.set(h, g);
        }
      }
    }
  }

  let input = 0, output = 0, cc = 0, cr = 0, maxCtx = 0;
  for (const { u } of s.usage.values()) {
    const i = u.input_tokens || 0, o = u.output_tokens || 0;
    const c1 = u.cache_creation_input_tokens || 0, c2 = u.cache_read_input_tokens || 0;
    input += i; output += o; cc += c1; cr += c2;
    maxCtx = Math.max(maxCtx, i + c1 + c2);
  }
  s.totals = { input, output, cc, cr, maxCtx, turns: mainTurns, totalTurns, compactions: 0 };
  s.totalTokens = input + output + cc + cr;

  let excessFresh = 0, excessCW = 0, excessCR = 0, compactions = 0, prev = 0, mainMaxCtx = 0, mainTokens = 0;
  for (const { u } of s.mainUsage.values()) {
    const i = u.input_tokens || 0, o = u.output_tokens || 0;
    const c1 = u.cache_creation_input_tokens || 0, c2 = u.cache_read_input_tokens || 0;
    const ctx = i + c1 + c2;
    mainMaxCtx = Math.max(mainMaxCtx, ctx);
    mainTokens += i + o + c1 + c2;
    const over = ctx - 40_000;
    if (over > 0) {
      const share = over / ctx;
      excessFresh += i * share;
      excessCW += c1 * share;
      excessCR += c2 * share;
    }
    if (prev > 50_000 && ctx < prev * 0.5) compactions++;
    prev = ctx;
  }
  s.excessFresh = excessFresh;
  s.excessCW = excessCW;
  s.excessCR = excessCR;
  s.mainMaxCtx = mainMaxCtx;
  s.mainTokens = mainTokens;
  s.totals.compactions = compactions;

  s.rereads = []; s.rereadWaste = 0;
  for (const r of s.reads.values()) {
    if (r.count < 3) continue;
    const w = (r.tokens * (r.count - 1)) / r.count;
    s.rereadWaste += w;
    s.rereads.push({ file: r.file, count: r.count, wasted: w });
  }
  s.loops = []; s.loopWaste = 0;
  for (const r of s.repeats.values()) {
    let best = null;
    for (const g of r.results.values()) if (!best || g.n > best.n) best = g;
    if (!best || best.n < 4) continue;
    const w = (best.tokens * (best.n - 1)) / best.n;
    s.loopWaste += w;
    s.loops.push({ label: r.label, runs: best.n, wasted: w });
  }

  let domKey = '', domW = 0;
  for (const [mk, e] of s.byModel) {
    const w = e.i + e.cw + e.cr;
    if (w > domW) { domW = w; domKey = mk; }
  }
  s.modelKey = domKey || 'sonnet-5-5';
  const dm = modelOf(s.modelKey);
  s.model = dm || { ...UNPRICED_FALLBACK, label: s.modelKey };
  s.tier = s.model.tier;

  let cost = 0;
  for (const e of s.byModel.values()) cost += e.cost;
  s.cost = cost;

  let mainW = 0, sideW = 0;
  for (const { u, isSidechain } of s.usage.values()) {
    const w = (u.input_tokens || 0) + (u.output_tokens || 0) + (u.cache_creation_input_tokens || 0) + (u.cache_read_input_tokens || 0) * 0.1;
    if (isSidechain) sideW += w; else mainW += w;
  }
  s.weighted = mainW + sideW;
  return s;
}

export function mainCostAtPrice(s, modelKey, priceFn) {
  let cost = 0;
  for (const { u, mk } of s.mainUsage.values()) {
    if (mk !== modelKey) continue;
    const ti = u.input_tokens || 0, to = u.output_tokens || 0;
    const tcw = u.cache_creation_input_tokens || 0, tcr = u.cache_read_input_tokens || 0;
    cost += costOf(ti, to, tcw, tcr, priceFn(ti + tcw + tcr));
  }
  return cost;
}

// ---------------------------------------------------------------------------
// 5. Classification + recommendation
// ---------------------------------------------------------------------------
export function classifyTask(s) {
  const edits = [...s.gen.values()].reduce((a, b) => a + b, 0);
  const filesEdited = s.gen.size;
  const writes = s.writesByFile ? [...s.writesByFile.values()].reduce((a, b) => a + b, 0) : 0;
  const createdFiles = s.wasCreated ? s.wasCreated.size : 0;
  const turns = s.totals.turns;
  const reads = [...s.reads.values()].reduce((a, r) => a + r.count, 0);
  const tests = s.bashCmds.filter(c => /\b(test|spec|jest|pytest|vitest|mocha|go test|cargo test)\b/i.test(c)).length;
  const fails = s.bashFails.length;
  const churn = filesEdited ? Math.max(...s.gen.values()) : 0;
  const longText = s.mainAssistantText > 5000;

  if (edits === 0 && writes === 0 && turns <= 8) return pick('lookup', 'high', `${reads} reads, no edits, ${turns} turns`);
  if (edits <= 2 && filesEdited <= 1 && turns <= 12 && writes === 0) return pick('simple-edit', 'high', `${edits} edit(s), one file, ${turns} turns`);
  if (createdFiles >= 3 && churn <= 2) return pick('boilerplate', 'high', `${createdFiles} new files, low churn`);
  if (createdFiles >= 1 && churn <= 2 && turns <= 10 && filesEdited <= 2) return pick('boilerplate', 'medium', `${createdFiles} new file(s), ${turns} turns`);
  if (fails > 0 && churn >= 2) {
    const hard = turns > 30 || fails > 3 || filesEdited > 3;
    return pick('debug', hard ? 'high' : 'medium', `${fails} failure(s), churn ${churn}, ${turns} turns`, hard ? 'opus' : 'sonnet');
  }
  if (filesEdited >= 5 && turns >= 20) return pick('refactor', 'high', `${filesEdited} files, ${turns} turns`);
  if (tests > 0 && edits > 0 && filesEdited <= 3 && createdFiles === 0) return pick('test-writing', 'high', `${tests} test run(s), ${edits} edits`);
  if (edits > 0 && turns <= 25) return pick('routine-coding', 'medium', `${edits} edits, ${turns} turns`);
  if (reads > edits * 2 && turns > 15) {
    if (longText && edits === 0) return pick('review', 'medium', `${reads} reads, long output`);
    return pick('investigation', 'medium', `${reads} reads vs ${edits} edits`);
  }
  if (longText && edits === 0) return pick('writing', 'medium', `long output, no edits`);
  if (edits <= 1 && turns > 15 && s.mainAssistantText > 15000 && reads < 15) return pick('architecture', 'low', `${turns} turns, long output, few tools`);
  if (s.mainMaxCtx > 100_000 && turns > 40) return pick('open-ended', 'low', `peak ${fmt(s.mainMaxCtx)}, ${turns} turns`);
  return pick('routine-coding', 'low', 'default');
}
function pick(task, confidence, evidence, overrideMin) {
  const t = TASKS[task];
  return { id: task, label: t.label, min: overrideMin || t.min, why: t.why, confidence, evidence };
}

function qualityBuffer(fromTier, toTier, taskId) {
  if (taskId === 'lookup' || taskId === 'simple-edit') return 0;
  if (taskId === 'boilerplate') return 0.05;
  const down = TIER_RANK[fromTier] - TIER_RANK[toTier];
  if (down <= 0) return 0;
  if (down === 1) return 0.10;
  if (down === 2) return 0.25;
  return 0.40;
}

export function recommendModel(s, task) {
  if (!TIER_RANK[s.tier]) return { switch: false, unpriced: true };
  if (TIER_RANK[task.min] >= TIER_RANK[s.tier]) return { switch: false };
  const target = TIER_KEY[task.min];
  const targetModel = MODELS[target];
  const buffer = qualityBuffer(s.tier, task.min, task.id);
  const actualMain = mainCostAtPrice(s, s.modelKey, ctx => priceForModel(s.model, ctx));
  const hypothetical = mainCostAtPrice(s, s.modelKey, ctx => priceForModel(targetModel, ctx)) * (1 + buffer);
  const saving = Math.max(0, actualMain - hypothetical);
  if (saving < 0.01) return { switch: false };
  return {
    switch: true,
    from: s.model.label,
    fromTier: s.tier,
    to: targetModel.label,
    toTier: task.min,
    saving,
    hypothetical,
    buffer,
    targetPrice: priceForModel(targetModel, 0),
  };
}

export function phrasingTips(s, task, rec) {
  const tips = [];
  const prompts = s.userPrompts.filter(Boolean);
  const vague = prompts.filter(p => p.split(/\s+/).length <= 8 && /^(fix|improve|make|clean|refactor|optimi[sz]e|update|change|add|rewrite)\b/i.test(p.trim()));
  if (vague.length) {
    const f = [...s.gen.keys()][0] || 'the file you are editing';
    const cmd = s.bashCmds.find(c => /test|run|build|lint/i.test(c)) || 'the relevant test';
    tips.push({
      kind: 'vague', count: vague.length,
      before: `"${vague[0].slice(0, 80)}"`,
      after: `"In ${path.basename(f)}, ${vague[0].replace(/^(fix|improve|make|clean|refactor|optimi[sz]e|update|change|add|rewrite)\s*/i, '').trim() || 'fix the issue'}. Make it work so ${cmd} passes."`,
      why: 'Naming the file and the done criterion stops Claude from exploring to guess.',
    });
  }
  const big = prompts.filter(p => p.length > 8000);
  if (big.length) tips.push({
    kind: 'big-paste', count: big.length,
    before: `${fmt(tok(big[0].length))} tokens pasted inline`,
    after: 'Attach the file, or quote only the failing lines. Say: "The error is in the last 20 lines of the attached log."',
    why: 'An inline paste is re-sent on every later turn; an attachment is read once and can be referenced.',
  });
  const multi = prompts.filter(p => (p.match(/^\s*(\d+[.)]|[-*])\s+\S/gm) || []).length >= 4);
  if (multi.length) tips.push({
    kind: 'multi-task', count: multi.length,
    before: `${(multi[0].match(/^\s*(\d+[.)]|[-*])\s+\S/gm) || []).length} tasks in one message`,
    after: 'Pick one task, finish it, then /clear and start the next. If you need a plan, ask for the plan first and approve it before any edits.',
    why: 'Every task in the same chat is re-sent on every later turn.',
  });
  if (rec && rec.switch) tips.push({
    kind: 'model', count: 1,
    before: `Using ${rec.from} for ${task.label.toLowerCase()}`,
    after: `"Use ${rec.to} for this."`,
    why: `${HELP_WHY[task.id] || 'The cheaper model is capable for this task shape.'} ${task.evidence}.`,
  });
  return tips;
}

// ---------------------------------------------------------------------------
// 6. Discovery + report
// ---------------------------------------------------------------------------
export function listSessions(root, days = 7) {
  const cutoff = days > 0 ? Date.now() - days * 864e5 : 0;
  const out = [];
  let dirs = [];
  try { dirs = fs.readdirSync(root, { withFileTypes: true }).filter(d => d.isDirectory()); } catch { return null; }
  for (const d of dirs) {
    const dp = path.join(root, d.name);
    let entries;
    try { entries = fs.readdirSync(dp); } catch { continue; }
    for (const f of entries) {
      if (!f.endsWith('.jsonl')) continue;
      const fp = path.join(dp, f);
      try { const mt = fs.statSync(fp).mtimeMs; if (mt >= cutoff) out.push({ file: fp, dirName: d.name, mt }); } catch {}
    }
  }
  return out.sort((a, b) => a.mt - b.mt);
}

export function runReport({ root, days = 7, projectFilter = null, minUsd = 0.03, top = 5 } = {}) {
  if (!root) {
    const config = process.env.CLAUDE_CONFIG_DIR || path.join(os.homedir(), '.claude');
    root = path.join(config, 'projects');
  }
  const files = listSessions(root, days);
  if (files === null) return { error: `No Claude Code logs found at ${root}` };

  const cutoff = days > 0 ? Date.now() - days * 864e5 : 0;
  const unpriced = new Set();
  const owners = new Map();
  const projects = new Map();
  const byModel = new Map();
  const byTask = new Map();
  const findings = [];
  const allTips = [];
  const rows = [];
  let sessions = 0, totalCost = 0, totalTokens = 0, totalMainTokens = 0, totalWeighted = 0, turns = 0;
  let switchSave = 0, contextSave = 0, totalReread = 0, totalLoop = 0;

  for (const { file, dirName } of files) {
    const s = analyzeSession(file, owners, cutoff, unpriced);
    if (!s || s.totals.totalTurns === 0) continue;
    const name = s.cwd ? pretty(s.cwd) : dirName;
    if (projectFilter && !name.includes(projectFilter)) continue;

    const task = classifyTask(s);
    const rec = recommendModel(s, task);
    s.rec = rec; s.name = name;
    s.id = path.basename(file, '.jsonl').slice(0, 12);

    sessions++;
    totalCost += s.cost;
    totalTokens += s.totalTokens;
    totalMainTokens += s.mainTokens;
    totalWeighted += s.weighted;
    turns += s.totals.turns;
    switchSave += rec.switch ? rec.saving : 0;
    totalReread += s.rereadWaste;
    totalLoop += s.loopWaste;

    for (const [mk, e] of s.byModel) {
      const mdl = modelOf(mk) || { label: mk, tier: 'unknown' };
      const label = mdl.label;
      const bm = byModel.get(label) || { label, tier: mdl.tier, sessions: 0, dominantSessions: 0, cost: 0, tokens: 0, switches: 0, save: 0 };
      bm.sessions++;
      bm.cost += e.cost;
      bm.tokens += e.i + e.o + e.cw + e.cr;
      byModel.set(label, bm);
    }
    if (rec.switch) { const bm = byModel.get(s.model.label); if (bm) { bm.switches++; bm.save += rec.saving; } }
    { const bm = byModel.get(s.model.label); if (bm) bm.dominantSessions++; }

    const p = projects.get(name) || { name, sessions: 0, turns: 0, cost: 0, cwd: s.cwd, switches: 0, save: 0, models: new Map() };
    p.sessions++; p.turns += s.totals.turns; p.cost += s.cost;
    p.models.set(s.model.label, (p.models.get(s.model.label) || 0) + s.cost);
    if (rec.switch) { p.switches++; p.save += rec.saving; }
    projects.set(name, p);

    const bt = byTask.get(task.id) || { id: task.id, label: task.label, sessions: 0, cost: 0, save: 0, min: task.min };
    bt.sessions++; bt.cost += s.cost; bt.save += rec.switch ? rec.saving : 0;
    byTask.set(task.id, bt);

    const eff = rec.switch ? rec.targetPrice : s.model;
    const wasteTok = s.rereadWaste + s.loopWaste;
    const totalExcess = s.excessFresh + s.excessCW + s.excessCR;
    let netFresh = s.excessFresh, netCW = s.excessCW, netCR = s.excessCR;
    if (totalExcess > 0 && wasteTok > 0) {
      const scale = Math.max(0, 1 - wasteTok / totalExcess);
      netFresh *= scale; netCW *= scale; netCR *= scale;
    }
    const ctxSave = (netFresh * eff.in + netCW * eff.cw + netCR * eff.cr) / 1e6
                  + (s.rereadWaste * eff.cr) / 1e6
                  + (s.loopWaste * eff.cr) / 1e6;
    contextSave += ctxSave;

    for (const r of s.rereads) findings.push({
      kind: 'repeated-reads', usd: (r.wasted * eff.cr) / 1e6, wasted: r.wasted,
      where: name, aggKey: 'f:' + r.file,
      title: `${path.basename(r.file)} read ${r.count}×, no edits between`,
      fix: 'Put the facts in CLAUDE.md, or tell Claude to keep notes instead of re-reading.',
    });
    for (const l of s.loops) findings.push({
      kind: 'tool-loop', usd: (l.wasted * eff.cr) / 1e6, wasted: l.wasted,
      where: name, aggKey: 'l:' + l.label,
      title: `Same call, same result ${l.runs}×: ${l.label}`,
      fix: 'Interrupt with the missing constraint, not "try again".',
    });
    const longTok = netFresh + netCW + netCR;
    const long = s.mainMaxCtx >= 150_000 || s.totals.turns >= 80;
    if (long && longTok > 0) findings.push({
      kind: 'long-session', usd: (netFresh * eff.in + netCW * eff.cw + netCR * eff.cr) / 1e6,
      wasted: longTok, where: name, aggKey: 's:' + s.id,
      title: `Session ${s.id}: ${s.totals.turns} turns, peak ${fmt(s.mainMaxCtx)}${s.totals.compactions ? `, ${s.totals.compactions} compactions` : ''}`,
      fix: '/clear between tasks; /compact when continuing a long one.',
    });
    if (rec.switch) findings.push({
      kind: 'model-switch', usd: rec.saving, wasted: 0, where: name, aggKey: 'm:' + s.modelKey + ':' + task.id,
      title: `${rec.from} → ${rec.to} for ${task.label.toLowerCase()}${rec.buffer ? ` (assumes +${Math.round(rec.buffer * 100)}% tokens)` : ''}`,
      fix: `Say: "Use ${rec.to} for this." ${HELP_WHY[task.id] || ''}`,
    });

    const tips = phrasingTips(s, task, rec);
    if (tips.length) allTips.push({ name, tips, task });

    const modelsArr = [];
    for (const [mk, e] of s.byModel) {
      const mdl = modelOf(mk) || { label: mk, tier: 'unknown' };
      modelsArr.push({ key: mk, label: mdl.label, tier: mdl.tier, i: e.i, o: e.o, cw: e.cw, cr: e.cr, cost: e.cost });
    }
    rows.push({
      id: s.id, name, model: s.model.label || s.modelKey, tier: s.tier,
      task: task.id, taskLabel: task.label, taskConfidence: task.confidence, taskEvidence: task.evidence,
      turns: s.totals.turns, input: s.totals.input, output: s.totals.output,
      cc: s.totals.cc, cr: s.totals.cr, maxCtx: s.totals.maxCtx,
      cost: s.cost, switchTo: rec.switch ? rec.to : null, switchSave: rec.switch ? rec.saving : 0,
      ctxSave, models: modelsArr,
    });
  }

  // Instruction-file bloat
  const seen = new Set();
  const instrFiles = [];
  const configDir = process.env.CLAUDE_CONFIG_DIR || path.join(os.homedir(), '.claude');
  for (const p of projects.values()) {
    if (!p.cwd) continue;
    let topLabel = null, topCost = -1;
    for (const [lbl, c] of p.models) if (c > topCost) { topCost = c; topLabel = lbl; }
    const topTierRaw = [...byModel.values()].find(m => m.label === topLabel)?.tier;
    const topTier = topTierRaw && TIER_KEY[topTierRaw] ? topTierRaw : 'sonnet';
    instrFiles.push([path.join(p.cwd, 'CLAUDE.md'), p.sessions, p.turns, p.name, topTier]);
  }
  instrFiles.push([path.join(configDir, 'CLAUDE.md'), sessions, turns, 'global', 'sonnet']);
  for (const [fp, n, tn, where, tier] of instrFiles) {
    if (seen.has(fp)) continue;
    seen.add(fp);
    let size;
    try { size = fs.statSync(fp).size; } catch { continue; }
    const t = tok(size);
    if (t < 2500) continue;
    const over = t - 2500;
    const eff = priceForTier(tier, 0);
    if (!eff) continue;
    const usdVal = (over * (n * eff.cw + tn * eff.cr)) / 1e6;
    if (usdVal < minUsd) continue;
    contextSave += usdVal;
    findings.push({
      kind: 'bloated-instructions', usd: usdVal, wasted: 0, where,
      aggKey: 'b:' + fp,
      title: `${pretty(fp)} ~${fmt(t)} tokens, loaded in ${n} session${n > 1 ? 's' : ''}`,
      fix: 'Move task-specific notes to files Claude reads on demand; keep only always-true facts here.',
    });
  }

  const totalSave = Math.min(totalCost, switchSave + contextSave);
  const pctSpend = pct(totalSave, totalCost);
  const ctxTokens = totalReread + totalLoop;
  const pctTokens = pct(ctxTokens, totalMainTokens);

  const agg = new Map();
  for (const f of findings) {
    const a = agg.get(f.aggKey) || { kind: f.kind, usd: 0, wasted: 0, count: 0, titles: [], where: new Set(), fix: f.fix };
    a.usd += f.usd; a.wasted += f.wasted || 0; a.count++;
    if (a.titles.length < 2) a.titles.push(f.title);
    a.where.add(f.where);
    agg.set(f.aggKey, a);
  }
  const aggFindings = [...agg.values()]
    .filter(a => a.usd >= minUsd)
    .sort((a, b) => b.usd - a.usd)
    .map(f => ({ kind: f.kind, usd: f.usd, wasted: f.wasted, count: f.count, titles: f.titles, where: [...f.where], fix: f.fix }));

  const tipsMap = new Map();
  for (const { tips } of allTips) for (const t of tips) {
    const e = tipsMap.get(t.kind) || { ...t, count: 0 };
    e.count += t.count;
    tipsMap.set(t.kind, e);
  }
  const tips = [...tipsMap.values()].sort((a, b) => b.count - a.count).slice(0, 8);

  return {
    meta: {
      days, sessions, projectFilter, minUsd, top,
      totalCost, totalTokens, totalMainTokens, totalWeighted, turns,
      switchSave, contextSave, totalSave, pctSpend, pctTokens,
      ctxTokens, totalReread, totalLoop,
      unpriced: [...unpriced],
    },
    byModel: [...byModel.values()].sort((a, b) => b.cost - a.cost),
    byTask: [...byTask.values()].sort((a, b) => b.cost - a.cost),
    byProject: [...projects.values()]
      .map(p => ({ name: p.name, sessions: p.sessions, turns: p.turns, cost: p.cost, switches: p.switches, save: p.save, models: Object.fromEntries(p.models) }))
      .sort((a, b) => b.cost - a.cost),
    findings: aggFindings,
    tips,
    rows,
  };
}

export function simulateFromRows(rows, targetTier) {
  const key = TIER_KEY[targetTier];
  if (!key) return null;
  const p = MODELS[key];
  let actual = 0, sim = 0;
  for (const r of rows) {
    actual += r.cost;
    for (const m of r.models) {
      sim += costOf(m.i, m.o, m.cw, m.cr, priceForModel(p, m.i + m.cw + m.cr));
    }
  }
  return { actual, sim, diff: actual - sim, targetLabel: p.label };
}

export function toCsv(report) {
  const lines = ['session,project,model,tier,task,task_confidence,turns,input,output,cache_write,cache_read,max_ctx,cost_usd,switch_to,switch_save_usd,context_save_usd'];
  for (const r of report.rows) {
    lines.push([
      r.id, JSON.stringify(r.name), r.model, r.tier, r.task, r.taskConfidence, r.turns,
      r.input, r.output, r.cc, r.cr, r.maxCtx,
      r.cost.toFixed(4), r.switchTo || '', (r.switchSave || 0).toFixed(4), (r.ctxSave || 0).toFixed(4),
    ].join(','));
  }
  return lines.join('\n') + '\n';
}