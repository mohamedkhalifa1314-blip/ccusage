// renderer/app.js — UI logic. Talks to main via window.api (see preload.cjs).
const $ = (id) => document.getElementById(id);
const state = { report: null, tab: 'overview', pricing: null, playbook: '', simTier: 'sonnet', demo: false };

// ---- formatting ----------------------------------------------------------
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const fmt = (n) => {
  n = Number(n) || 0;
  if (n >= 1e9) return (n / 1e9).toFixed(2) + 'B';
  if (n >= 1e6) return (n / 1e6).toFixed(2) + 'M';
  if (n >= 1e3) return (n / 1e3).toFixed(1) + 'k';
  return String(Math.round(n));
};
const usd = (n) => {
  n = Number(n) || 0;
  if (n !== 0 && Math.abs(n) < 0.01) return '<$0.01';
  return '$' + n.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
};
const pctStr = (n) => (Number(n) || 0).toFixed(1) + '%';

function toast(msg, kind = 'ok') {
  const t = $('toast');
  t.textContent = msg;
  t.className = 'toast show ' + kind;
  clearTimeout(toast._t);
  toast._t = setTimeout(() => { t.className = 'toast'; }, 3000);
}

// ---- filters -------------------------------------------------------------
function readFilters() {
  return {
    days: Number($('f-days').value),
    projectFilter: $('f-project').value.trim() || null,
    minUsd: Number($('f-min').value) || 0,
    top: Number($('f-top').value) || 0,
    demo: state.demo,
  };
}

async function refresh() {
  const btn = $('refresh');
  btn.disabled = true;
  $('view').innerHTML = '<div class="loading">Analyzing…</div>';
  try {
    state.report = await window.api.runReport(readFilters());
  } catch (err) {
    state.report = { error: String(err?.message || err) };
  }
  btn.disabled = false;
  $('subtitle').textContent = state.demo ? 'DEMO DATA (fake numbers)' : "find what's burning your usage";
  $('demo-btn').textContent = state.demo ? '■ Exit demo' : '▶ Demo';
  renderStats();
  renderView();
}

// ---- stats bar -----------------------------------------------------------
function stat(label, value, sub, cls = '') {
  return `<div class="stat"><div class="stat-label">${esc(label)}</div><div class="stat-value ${cls}">${value}</div><div class="stat-sub">${esc(sub || '')}</div></div>`;
}
function renderStats() {
  const r = state.report;
  if (!r || r.error) { $('stats').innerHTML = ''; return; }
  const m = r.meta;
  $('stats').innerHTML =
    stat('Spend', usd(m.totalCost), `${m.days ? 'last ' + m.days + 'd' : 'all time'}`) +
    stat('Sessions', fmt(m.sessions), `${fmt(m.turns)} turns`) +
    stat('Tokens', fmt(m.totalTokens), `${fmt(m.totalMainTokens)} main thread`) +
    stat('Potential savings', usd(m.totalSave), pctStr(m.pctSpend) + ' of spend', 'success') +
    stat('Context waste', pctStr(m.pctTokens), `${fmt(m.ctxTokens)} tokens re-read / looped`, m.pctTokens > 10 ? 'warning' : '');
}

// ---- views ---------------------------------------------------------------
function table(headers, rows) {
  if (!rows.length) return '<p class="muted">Nothing to show.</p>';
  const th = headers.map((h) => `<th class="${h.num ? 'num' : ''}">${esc(h.t)}</th>`).join('');
  const tr = rows.map((r) => '<tr>' + r.map((c, i) => `<td class="${headers[i].num ? 'num' : ''}">${c}</td>`).join('') + '</tr>').join('');
  return `<table class="tbl"><thead><tr>${th}</tr></thead><tbody>${tr}</tbody></table>`;
}

function findingItem(f) {
  const title = f.count > 1 ? `${esc(f.titles[0])} <span class="muted">(+${f.count - 1} more)</span>` : esc(f.titles[0]);
  return `<li>
    <div class="finding-head">
      <span class="finding-usd">${usd(f.usd)}</span>
      <span class="badge kind">${esc(f.kind)}</span>
      <span class="muted small">${esc(f.where.slice(0, 3).join(', '))}${f.where.length > 3 ? '…' : ''}</span>
    </div>
    <div class="finding-title">${title}</div>
    <div class="finding-fix">${esc(f.fix)}</div>
  </li>`;
}

function viewOverview(r) {
  const m = r.meta;
  const total = Math.max(m.switchSave + m.contextSave, 0.0001);
  const lever = (name, v, cls) => `<div class="lever">
      <div class="lever-head"><span>${name}</span><span class="mono ${cls}">${usd(v)}</span></div>
      <div class="bar"><div class="bar-fill ${cls === 'success' ? 'success' : ''}" style="width:${Math.min(100, (v / total) * 100)}%"></div></div>
    </div>`;
  const top = r.findings.slice(0, r.meta.top || r.findings.length);
  return `
    <div class="panel"><h2>Where the savings are <span class="muted">· ${usd(m.totalSave)} (${pctStr(m.pctSpend)} of spend)</span></h2>
      ${lever('Switch to a cheaper model where the task allows', m.switchSave, 'accent')}
      ${lever('Trim context: re-reads, loops, long sessions, bloated CLAUDE.md', m.contextSave, 'success')}
    </div>
    <div class="panel"><h2>Top findings</h2>
      ${top.length ? `<ol class="findings">${top.map(findingItem).join('')}</ol>` : '<p class="muted">No findings above the minimum $.</p>'}
    </div>
    ${m.unpriced.length ? `<div class="panel"><h2>Unpriced models</h2><p class="muted small">No price on file, used a Sonnet-class fallback: <code>${esc(m.unpriced.join(', '))}</code></p></div>` : ''}`;
}

function viewFindings(r) {
  return `<div class="panel"><h2>All findings <span class="muted">· ${r.findings.length}</span></h2>
    ${r.findings.length ? `<ol class="findings">${r.findings.map(findingItem).join('')}</ol>` : '<p class="muted">No findings above the minimum $.</p>'}</div>`;
}

function viewModels(r) {
  return `<div class="panel"><h2>Spend by model</h2>${table(
    [{ t: 'Model' }, { t: 'Tier' }, { t: 'Sessions', num: 1 }, { t: 'Main in', num: 1 }, { t: 'Tokens', num: 1 }, { t: 'Cost', num: 1 }, { t: 'Switches', num: 1 }, { t: 'Save', num: 1 }],
    r.byModel.map((x) => [esc(x.label), esc(x.tier), x.sessions, x.dominantSessions, fmt(x.tokens), usd(x.cost), x.switches, usd(x.save)])
  ).replace('Main in', 'Dominant in')}</div>`;
}

function viewTasks(r) {
  return `<div class="panel"><h2>Spend by task type</h2>${table(
    [{ t: 'Task' }, { t: 'Sessions', num: 1 }, { t: 'Cost', num: 1 }, { t: 'Savings', num: 1 }],
    r.byTask.map((x) => [esc(x.label), x.sessions, usd(x.cost), usd(x.save)])
  )}</div>`;
}

function viewProjects(r) {
  return `<div class="panel"><h2>Spend by project</h2>${table(
    [{ t: 'Project' }, { t: 'Sessions', num: 1 }, { t: 'Turns', num: 1 }, { t: 'Cost', num: 1 }, { t: 'Switches', num: 1 }, { t: 'Save', num: 1 }],
    r.byProject.map((x) => [`<span class="mono">${esc(x.name)}</span>`, x.sessions, fmt(x.turns), usd(x.cost), x.switches, usd(x.save)])
  )}</div>`;
}

function viewTips(r) {
  if (!r.tips.length) return '<div class="panel"><h2>Prompt tips</h2><p class="muted">No phrasing issues found in this range.</p></div>';
  return `<div class="panel"><h2>Prompt tips</h2>${r.tips.map((t) => `
    <div class="tip">
      <div class="tip-head"><span class="badge kind">${esc(t.kind)}</span> <span class="muted small">× ${t.count}</span></div>
      <div class="tip-before">− ${esc(t.before)}</div>
      <div class="tip-after">+ ${esc(t.after)}</div>
      <div class="muted small">${esc(t.why)}</div>
    </div>`).join('')}</div>`;
}

// Simulate: same math as core.js costOf / priceForModel.
function priceFor(model, ctx) { return model.hi && ctx > 100000 ? model.hi : model; }
function simulate(rows, tier) {
  const p = state.pricing.models[state.pricing.tierKey[tier]];
  let actual = 0, sim = 0;
  for (const row of rows) {
    actual += row.cost;
    for (const m of row.models) {
      const pr = priceFor(p, m.i + m.cw + m.cr);
      sim += (m.i * pr.in + m.o * pr.out + m.cw * pr.cw + m.cr * pr.cr) / 1e6;
    }
  }
  return { actual, sim, diff: actual - sim, label: p.label };
}
function viewSimulate(r) {
  const pr = state.pricing;
  const opts = pr.tierOrder.map((t) => `<option value="${t}" ${t === state.simTier ? 'selected' : ''}>${esc(pr.tierLabel[t])}</option>`).join('');
  const s = simulate(r.rows, state.simTier);
  const cls = s.diff >= 0 ? 'success' : 'danger';
  return `<div class="panel"><h2>What if everything ran on one model?</h2>
    <p class="muted small">Replays your token counts at another model's prices. Cheaper models may need more tokens or retries, so treat it as an upper bound.</p>
    <div class="row"><label class="f"><span>Target model</span><select id="sim-tier">${opts}</select></label></div>
    <div class="sim-grid">
      ${stat('Actual', usd(s.actual), 'what you paid')}
      ${stat('On ' + s.label, usd(s.sim), 'same tokens')}
      ${stat(s.diff >= 0 ? 'Would save' : 'Would cost more', usd(Math.abs(s.diff)), pctStr(s.actual ? (Math.abs(s.diff) / s.actual) * 100 : 0), cls)}
    </div></div>`;
}

function viewPricing() {
  const pr = state.pricing;
  const rows = Object.entries(pr.models).map(([k, m]) => [
    esc(m.label), esc(m.tier), '$' + m.in, '$' + m.out, '$' + m.cw, '$' + m.cr,
    m.hi ? `>100k ctx: $${m.hi.in} / $${m.hi.out}` : '',
  ]);
  return `<div class="panel"><h2>Pricing <span class="muted">· USD per million tokens</span></h2>${table(
    [{ t: 'Model' }, { t: 'Tier' }, { t: 'Input', num: 1 }, { t: 'Output', num: 1 }, { t: 'Cache write', num: 1 }, { t: 'Cache read', num: 1 }, { t: 'Note' }],
    rows
  )}</div>`;
}

function viewPlaybook() {
  return `<div class="panel"><h2>Playbook</h2><pre class="playbook">${esc(state.playbook)}</pre></div>`;
}

function renderView() {
  const r = state.report;
  const v = $('view');
  if (!r) { v.innerHTML = '<div class="loading">Analyzing…</div>'; return; }
  if (r.error) { v.innerHTML = `<div class="error">${esc(r.error)}<br><span class="muted small">Click ⚙ to set the logs directory, or try the demo.</span><br><br><button id="demo-inline" class="primary">Load demo data</button></div>`;
    const di = $('demo-inline'); if (di) di.addEventListener('click', toggleDemo);
    return; }
  const needsData = !['pricing', 'playbook'].includes(state.tab);
  if (needsData && r.meta.sessions === 0) {
    v.innerHTML = '<div class="panel"><p class="muted">No sessions in this range. Widen the range or clear the project filter.</p></div>';
    return;
  }
  const views = {
    overview: viewOverview, findings: viewFindings, models: viewModels, tasks: viewTasks,
    projects: viewProjects, tips: viewTips, simulate: viewSimulate, pricing: viewPricing, playbook: viewPlaybook,
  };
  v.innerHTML = (views[state.tab] || viewOverview)(r);
  const sel = $('sim-tier');
  if (sel) sel.addEventListener('change', () => { state.simTier = sel.value; renderView(); });
}

// ---- events --------------------------------------------------------------
$('tabs').addEventListener('click', (e) => {
  const b = e.target.closest('button[data-tab]');
  if (!b) return;
  state.tab = b.dataset.tab;
  document.querySelectorAll('#tabs button').forEach((x) => x.classList.toggle('active', x === b));
  renderView();
});
$('refresh').addEventListener('click', refresh);
function toggleDemo() { state.demo = !state.demo; refresh(); }
$('demo-btn').addEventListener('click', toggleDemo);
['f-project', 'f-min', 'f-top'].forEach((id) => $(id).addEventListener('keydown', (e) => { if (e.key === 'Enter') refresh(); }));
$('f-days').addEventListener('change', refresh);

async function exportAs(kind) {
  const r = state.report;
  if (!r || r.error) return toast('Nothing to export', 'err');
  const stamp = new Date().toISOString().slice(0, 10);
  const opts = kind === 'json'
    ? { defaultName: `ccwaste-${stamp}.json`, content: JSON.stringify(r, null, 2), filters: [{ name: 'JSON', extensions: ['json'] }] }
    : { defaultName: `ccwaste-${stamp}.csv`, content: await window.api.toCsv(r), filters: [{ name: 'CSV', extensions: ['csv'] }] };
  try {
    const res = await window.api.saveFile(opts);
    if (!res.canceled) toast('Saved ' + res.path);
  } catch (err) { toast(String(err?.message || err), 'err'); }
}
$('export-json').addEventListener('click', () => exportAs('json'));
$('export-csv').addEventListener('click', () => exportAs('csv'));

const dlg = $('settings');
$('settings-btn').addEventListener('click', async () => {
  const s = await window.api.getSettings();
  $('s-dir').value = s.dir || '';
  dlg.showModal();
});
$('s-browse').addEventListener('click', async () => {
  const d = await window.api.chooseDir();
  if (d) $('s-dir').value = d;
});
$('s-save').addEventListener('click', async () => {
  await window.api.setSettings({ dir: $('s-dir').value });
  toast('Settings saved');
  refresh();
});

// ---- boot ----------------------------------------------------------------
(async function init() {
  try {
    [state.pricing, state.playbook] = await Promise.all([window.api.getPricing(), window.api.getPlaybook()]);
  } catch (err) { toast('Preload failed: ' + err.message, 'err'); }
  refresh();
})();
