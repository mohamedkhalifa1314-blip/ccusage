# ccwaste-desktop

A desktop app that reads your Claude Code session logs and shows where usage is wasted: repeated file reads, tool loops, long sessions, bloated `CLAUDE.md` files, and tasks that could run on a cheaper model.

Dollar figures are estimates. They use the prices in `core.js`, which may not match current Anthropic pricing. Check the official price list before relying on them. If you use a subscription plan, the figures show what the same usage would cost on the API, not your bill.

This project is not affiliated with or endorsed by Anthropic.

## Requirements

- Node.js 18 or higher
- Claude Code, with session logs in `~/.claude/projects` (or `$CLAUDE_CONFIG_DIR/projects`)

Without Claude Code logs, the app opens but has nothing to analyze.

## Run

```bash
npm install
npm start
```

On Windows PowerShell, use `npm.cmd install` and `npm.cmd start` if scripts are blocked.

If your logs are somewhere else, click the gear icon and set the folder.

## Package

```bash
npm run dist
```

Output goes to `dist/`.

## Files

- `main.js`: Electron main process
- `preload.cjs`: bridge between main and the UI
- `core.js`: log analysis and pricing
- `demo.js`: generates fake logs for the Demo button
- `renderer/`: the UI

## License

MIT. See `LICENSE`.
